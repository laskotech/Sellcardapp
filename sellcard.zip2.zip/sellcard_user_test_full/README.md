
# Sell Card — User Test Build (Flutter)

Includes:
- Firebase **Phone OTP** login (automatic SMS by Firebase)
- **Upload Card**: brand, value, photo
- **My Cards**: shows submissions (status = `pending_review`)
- Light mode UI + professional icon
- `google-services.json` already placed for Firebase project `my-awesome-app-c974b`

## Build APK
```
flutter pub get
flutter build apk --release
```
APK: `build/app/outputs/flutter-apk/app-release.apk`
